%NOTE FOR THE USER
%Change CSV file name in line 27 to pull in wind data from different years

%Input GUI and Variable Assignment
clc;
clear;
GUIFields = {'Please Enter Wind Turbine Model:', 'Please Enter Rotor Diameter (in m):', 'Please Enter Cut-in Velocity (in m/s):','Please Enter Rated Velocity (in m/s):','Please Enter Efficiency:'};
dlgtitle = 'Welcome to the Turbine Energy Simulator';
dims = [1 100];
definput = {'Vestas: V100','100','3','12','0.45'};
userInput = inputdlg (GUIFields,dlgtitle,dims,definput);
[Model, rD, vC, vR, n] = deal(userInput{:});

%Converting user input into numeric values
rD = str2double (rD); %Convert Rotor Diameter to RADIUS
%h = str2double (h); Not including Rotor height as a variable since it doesn't impact the power calculation formula
vC = str2double (vC);
vR = str2double (vR);
n = str2double (n);

%Read Model Data can be added to simplify user input into just the name and the values. This user input can then allow for the Turbine model information to be pulled in from a known data repository.

%Read Wind data. Currently reading from spreadsheet. Can expand on
%this code to enable reading a segment (shorter time duration) from a large
%spreadsheet (spanning large time intervals)

%Using this smaller dataset to test and setup the model
%[simTime, V] = readvars ('WindData_v1.xlsx');        %Small Dataset
[simTime, V] = readvars ('Hourly Wind Speed - 2012 Capser WY.csv');      %Large Dataset
dataPoints = size (V, 1);


%Power Formula (verify again with inclusion of Cp)
%Fixed air density at 20C of 1.204 kg/m^3
rho = 1.204; 
P = zeros(dataPoints, 1);
currentPower = zeros(dataPoints, 1);



%Actual power achievable from a 270MW "rated" wind farm is 0.3*270 (since wind power capacity is 30% (Reference)) 
actualPower = 81;   %in MW

farmCapFactor = 1;    % Land-based wind farm capacity factor assumption is ~30%. Leaving it at 1 since the true power factor has already included this (above)
targetPower = actualPower * 365 * 24 * farmCapFactor;   % 270MW for 365 days and 24 hours with a capacity factor of 25%
safetyFactor = 1.2;    % Variable used to capture maintenance times, wind variability, other factors
reqPowerMW = targetPower * safetyFactor;   % Real required power after considering assumptions / variability


%PLEASE NOTE that some variable names may be called Power or Energy but may not pertain to the true type of variable.


for i = 1 : 500  %Loop to increase number of turbines. Make 500 as a large enough variable n that has to be minimized based on Power needed

    for j = 1 : dataPoints
        instV = V (j,1);                      %Instantaneous Velocity (per hour) extraction array
        
        %Stretch Goal: Also record time data to provide information to the user as to when the required power is reached
            %instT = simTime (j,1);  %Instantaneous Time extraction array
        %This requires datetime to double conversion. Modify incoming spreadsheet to help with parsing this information
            %External script to convert the day and hour information into 1 hour segments. SQL / Python may help with that function
        
        %Conditions for Cut-in velocity and Rated velocity. Turbine operates only within the sweet-spot
        if V(j,1) < vC | V(j,1) > vR
        instPower = 0;
        
        else
        instPower = (0.5 * pi * (rD/2) * (rD/2) * rho * n * (instV ^ 3)) * i;    
        
        end
        
        P (j) = instPower * 10^(-6);  %W to MW conversion   
        currentPower = sum (P);
        
        if currentPower > reqPowerMW;
            break;
            
        else
       
        end
                
    end
    
        %Checking for total power for a given number of turbines
        totPower (i, :) = sum (P); 
        
        if totPower (i,:) < reqPowerMW;
          
            i = i + 1;   
           
        else
            numTurb = i;
            break;
            
        end
       
%         Plot the Power Output vs Number of Turbines
%         figure (2)
%         set(gcf,'position',[900,250,800,500])
%         Custom plot formatting
%         %plot (simTime, P, 'LineStyle', '-', 'Color', '#0072BD', 'Marker', 'o', 'MarkerSize', 8, 'MarkerFaceColor', 'r', 'LineWidth', 2);
%         plot (i, P, 'LineStyle', '--', 'Marker', 'square', 'MarkerSize', 8, 'LineWidth', 2);
%         title('Number of Turbines vs Power Output');
%         xlabel('Number of Turbines'); 
%         ylabel('Power Generated (MW)');
        
        

%         legendInfo{i} = ['Power from ', num2str(i), 'turbine(s)'];
%         legend(legendInfo)
%         legend show
%         set(gca, 'Units','normalized', 'FontUnits','points','FontWeight','normal', 'FontSize',14,'FontName','Arial');
%         grid on
%         hold on
        

end

        %Plot the Power Output vs time (here, per hour)
        figure (1)
        set(gcf,'position',[100,360,1500,500])
        %Custom plot formatting
        plot (simTime, P, 'LineStyle', '-', 'Marker', 'o', 'MarkerSize', 1, 'LineWidth', 1);
        title('Power vs Time Distribution for Varying Wind Speeds');
        xlabel('Time (hours)'); 
        ylabel('Power Generated (MW)');

        legendInfo = ['Power from ', num2str(i), 'turbine(s)'];   %Have i in legendInfo when in a loop
        legend (legendInfo);
        legend show
        set(gca, 'Units','normalized', 'FontUnits','points','FontWeight','normal', 'FontSize',14,'FontName','Arial');
        grid on
        grid minor
        hold on
    
%     CHECK THIS LOOP For Ouput Stopping @ Power Limit
%     if totP > 218000;
%             break;
%     end
        
    %Output to Excel File
    %writematrix (totP (:,i), Model (:,i), '/Users/ashthomas/Library/Mobile Documents/com~apple~icloud~applecorporate/Documents/Miscellaneous/GATech-Ash/ASE6003/GP1/WindOutput_Turbines.xlsx');


%~~~~~~~~~3D Plot to lay out random number of Turbines in a land~~~~~~~~
% figure (3)
% [x,y] = meshgrid(0:1:499);
% zlim ([0 1]);
% z = ones (500) .* linspace(1,1,500);
% 
% surf (x, y, z);
% 
%     [xx,yy] = meshgrid(x,y);
%     zz = xx.*exp(-xx.^2-yy.^2);
%     [px,py] = gradient(zz,.2,.2);
% 
%     quiver(x,y,px,py)
%     xlim([0 500]);
%     ylim ([0 500]);
    
%     wTurbine=imread('Wind-Turbine-580x386.jpeg');
%     plot([.1 .9],[.2 1]);
%     axis([0 1 0 1]);
%     hold on;
%     imagesc([.5 .5], [.6 .6], wTurbine);

%Power in GW;
reqPowerGW = reqPowerMW * (10^-3);
totPowerGW = totPower .* (10^-3);

%User Output
fprintf('<strong> User Data Summary </strong>\n');
fprintf(' -------------------\n');

%PLEASE NOTE that some variable names may be called Power or Energy but may not pertain to the true type of variable.  

formatPow1 = ' <strong>%3.0f turbine(s)</strong> would be required to meet the required energy output of <strong>%3.0f GWh.</strong> \n';
fprintf(formatPow1, numTurb, reqPowerGW);

formatPow2 = ' The net energy produced by %3.0f turbine(s) is <strong>%5.2f GWh.</strong> \n';
fprintf(formatPow2, numTurb, totPowerGW(numTurb,:));

%Land Usage Measure
%Turbine spacing variable
tSpacing = 1.5 * rD; %Half of 3 x rD 
landArea = 1.554e+7; %In m^2 (6 sq miles = 3840 acres = 1.554e+7 m^2)

turbCoverage = (pi * tSpacing * tSpacing);    %Turbine coverage in m^2
turbCoverageAcres = turbCoverage * 0.000247105;   %Turbine coverage conversion to acres
turbCoverageSqMiles = turbCoverage * 3.861e-7;   %Turbine coverage conversion to Sq Miles

coveragePercentage = ((turbCoverage * numTurb) / landArea) * 100;


formatLand2 = ' Each turbine of this model takes up <strong>%2.3f sq miles (%2.2f acres)</strong> of land area \n (including inter-turbine spacing). \n';
fprintf(formatLand2, turbCoverageSqMiles, turbCoverageAcres);

formatLand3 = ' Overall land use is <strong>%2.2f%%</strong> \n';
fprintf(formatLand3, coveragePercentage);

%Failure message if land size is exceeded
if coveragePercentage > 100;
formatFail = ' ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ \n The model <strong>%s is NOT recommended</strong> since the target energy output cannot be achieved within 6 sq miles. \n The allowable number of turbines <strong>exceed wind farm size.</strong> \n';
fprintf(formatFail, Model);    

%Success message if land size is within limit
else
formatSuccess = ' ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ \n The model %s <strong>may be used</strong> to achieve required energy output. \n';
fprintf(formatSuccess, Model); 
    
end